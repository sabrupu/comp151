# Write a program that tells whether a triangle is Equilateral, Isosceles, or Scalene.
# Equilateral: All 3 sides are equal. 5 5 5
# Isosceles: 2 sides are equal. 5 5 10
# Scalene: 0 sides are equal. 5 3 10


def triangle_sides(S1, S2, S3):
    if S1 == S2 and S2 == S3:
        print('I am an equilateral.')
    elif S1 != S2 or S2 == S3 or S2 == S1:
        print('I am an isosceles.')
    else:
        print('I am a scalene.')


def main():
    side1 = int(input('Enter a number: '))
    side2 = int(input('Enter a number: '))
    side3 = int(input('Enter a number: '))

    ans = triangle_sides(side1, side2, side3)
    print(ans)

main()