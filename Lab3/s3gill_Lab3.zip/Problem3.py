# Write a program that will accept a month’s # and return the number of days in that
# month.
# Enter a month: 2
# That month has 28 days (29 on a leap year!)
# Enter a month: 10
# That month has 31 days!
